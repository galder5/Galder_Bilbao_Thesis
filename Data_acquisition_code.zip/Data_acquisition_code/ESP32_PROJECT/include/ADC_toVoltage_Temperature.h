#ifndef ADC_TOVOLTAGE_TEMPERATURE_H
#define ADC_TOVOLTAGE_TEMPERATURE_H
#include <cstdint>

#ifdef __cplusplus
extern "C" {
#endif

#define DAC 0x33       // Dirección del DAC (puedes mantenerlo si usas I2C)
#define DACREF 1.028   // DAC configurado a 1.024V
#define half_M 32768   // 2^16 niveles para diferencial
#define Gain 16        // Ganancia del PGA

void ADC_SetVREF();
/**
 * @brief Configura la referencia del ADC (VREF)
 */

float ADC_GetVREF();
/**
 * @return La referencia de voltaje previamente medida
 */

// Reemplaza 'diff_adc_result_t' por el tipo adecuado (ej. int16_t)
float ADC_DifftoVoltage(bool viaPGA, int16_t diffres);
/**
 * @brief Convierte una lectura diferencial del ADC en voltaje
 * @param viaPGA Indica si la señal pasó por amplificador
 * @param diffres Resultado diferencial del ADC
 * @return Voltaje medido
 */

#ifdef __cplusplus
}
#endif

#endif
