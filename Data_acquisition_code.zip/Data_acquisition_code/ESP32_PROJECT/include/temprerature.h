#ifndef THERMOCOUPLE_H
#define THERMOCOUPLE_H

#include "ADC_toVoltage_Temperature.h"

#ifdef __cplusplus
extern "C" {
#endif

// Funciones para medición de temperatura
float measure_Tt(int phase);
//measure the total temperature given the phase at which you want to measure
/**RTD at:
 * Between compressor and combustor: Tt3 -> phase = 3
 */
/**Termocouples at:
 * Bellmouth: Tt1 -> phase = 1
 * Between compressor and combustor: Tt3 -> phase = 3
 * Between combustor and turbine: Tt4 -> phase = 4
 * Nozzle exit: Tt9 -> phase = 9
 */


float compute_Thermocouple();
// Convierte el voltaje del ADC en temperatura usando la fórmula del AD8495
//read the ADC output, translate it to voltage and compute T using the AD8495 formula
/**AD8495 on Adafruit board: V = T*5mV+1.25 (T in *C)
 * AD8495 on modified Adafruit board (Vref = 0V): V = T*5mV (T in *C, +273 K)
*/

float compute_RTD();
// Calcula la resistencia de un PT100 y convierte a temperatura
//perform a differential measure, translate it to resistance and compute T using the PT100 formula
/** R_PT =  V_mV + OFFSET is calibrated and hardcoded above
 *  R_PT = R_PT0 + ALPHA*T
 */

// Definiciones de constantes
#define REF_CHANNEL 0x06  // Canal negativo de referencia para RTD
#define R_PT0       100   // Resistencia base del PT100
#define ALPHA       0.385 // Coeficiente de temperatura del PT100
#define OFFSET      -8    // Offset del circuito en mV

#ifdef __cplusplus
}
#endif

#endif
