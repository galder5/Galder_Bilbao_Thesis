#include <Wire.h>
#include <Adafruit_ADS1X15.h>

Adafruit_ADS1115 ads;  /* Use this for the 16-bit version */

float Voltage = 0.0;
uint8_t PIN_SDA = 17;
uint8_t PIN_SCL = 18;

void setup(void) 
{
  Serial.begin(115200);
  Serial.println("Iniciando...");

  // Definir manualmente los pines SDA y SCL
  Wire.begin(PIN_SDA, PIN_SCL);  // SDA = GPIO17, SCL = GPIO18

  if (!ads.begin(0x48)) {
    Serial.println("No se detectó el ADS1115. Revisa conexiones.");
    while (1); // Detener si falla
  }
}

void loop(void) 
{
  int16_t adc0;

  adc0 = ads.readADC_SingleEnded(0);
  Voltage = (adc0 * 0.1875) / 1000;

  Serial.print("AIN0: "); 
  Serial.print(adc0);
  Serial.print("\tVoltage: ");
  Serial.println(Voltage, 7); 
  Serial.println();

  delay(1000);
}